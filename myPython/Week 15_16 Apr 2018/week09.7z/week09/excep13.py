# finally, let you execute code even if an error occurs and whether you handle this error with except or not
try:
    x = float(input("Your number: "))
    inverse = 1.0 / x
except ZeroDivisionError:
	print ("div by 0")
finally:# finally block is always executed regardless the exception status
	print("There may or may not have been an exception.")
	print("we just tried\"finally\"")
	print ("by the way, finally is another try clause")
print("That's so clean output!")