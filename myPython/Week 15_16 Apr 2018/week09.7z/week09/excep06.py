#catch this exception
x =1
print (eval ('x===1'))


















try:
	x =1
	print (eval ('x===1'))
except SyntaxError:
	print (" Error: eval has a syntax error")