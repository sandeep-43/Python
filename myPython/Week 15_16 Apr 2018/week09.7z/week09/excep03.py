try:
	val = int(input("Enter a number: "))
	result = 5.0 / val

except ValueError:
    print("You must provide either an integer or a float")
except ZeroDivisionError:
#except Exception
	print("You can not divide by zero")
else:
	print("There may be an exception.")
def main():
	value = 10
	value1= changevalue(value)
	print ('The value is ', value, value1)
	#value = changevalue(value)
def changevalue(value):
	#value = 50
	value=value+10
	return value
#calls main
main()