
#Catch this exception!

value =int(inpt('enter a value'))
print ('after call', value)






















#try:
value =int(inpt('enter a value'))
print ('after call', value)
#except NameError:
print (" Error in the Name of the identifier!")