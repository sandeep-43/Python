import math
print(math.sqrt(4))










try:
	import math
	print(sqrt(4))
except Exception:
	print ("Error: check your math module!")