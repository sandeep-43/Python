f3 = open("testfile", "w")
try:
	f3.wrte("This file is a testing file for exception handling!!")
#finally:
	#print ("The testfile is closing, now")
	#f3.close()
except:
	print ("fgfgg")
i=7
g=4
print (i+g)





print("\n")
print("\n")





try:
	f3 = open("testfile", "w")
	try:
		f3.wrte("This file is a testing file for exception handling!!")
	finally:
		print ("The testfile is closing, now")
		f3.close()
except AttributeError as arg:
	print ("Error: can\'t find file or read data", arg)
i=7
g=4
print (i+g)