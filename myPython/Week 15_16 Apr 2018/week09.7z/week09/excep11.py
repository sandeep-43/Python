#f = open('integers.txt', 'w+')
#s = f.readline()
#i = int(s.strip())




try:
    f = open('integers.txt', 'w+')
    s = f.readline()
    i = int(s.strip())
except ValueError as arg:
    print("An I/O error or a ValueError occurred",arg)
except:
    print("An unexpected error occurred",arg)