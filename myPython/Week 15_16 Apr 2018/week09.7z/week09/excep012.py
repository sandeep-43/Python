while True:
	try:
		n = input("Please enter an integer: ")
		n = int(n)
		break
	except ValueError:
		print("No valid integer! Please try again ...")
	finally:
		print("Great, you successfully entered an integer!")