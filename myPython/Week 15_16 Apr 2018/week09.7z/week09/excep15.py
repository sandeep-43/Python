def temp_convert(var):
	return int(var)
print ("The argument does not contain numbers\n")

# Call above function here.
#z = int(input("enter"))
temp_convert("xyz")
#temp_convert(z)