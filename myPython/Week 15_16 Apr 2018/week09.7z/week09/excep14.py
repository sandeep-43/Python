try:
	val = float(input("Enter a number: "))
	result = 5.0 / val
except ValueError:
	print("You must provide either an integer or a float")
except ZeroDivisionError:
	print("You can not divide by zero")
except:
	print ("Unexpected error")
#finally:
	#print ("it is finally")
#print ("hello")
	
