# def f():
	# try:
		# v = input("Enter a number: ")
		# x = int(v)
	# #except ValueError as e:
	# except:
		# print("got it in the function :-) ")

# f()
# y =4
# y +=5
# print (y)
def f():
	v = input("Enter a number: ")
	x = int(v)
f()
y =4
y +=5
print (y)