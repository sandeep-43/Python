def printint(x):
	try:
		x=x+1
		print ("The integer is: ", x)
	except Exception as argument:
		print ("The argument does not contain numbers\n",argument)
#val= int(input("Enter an integer number: "))
val= input("Enter an integer number: ")
printint(val)
print("hh")