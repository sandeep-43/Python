val = float(input("Enter a number: "))
result = 5.0 / val
def main():
	value = 10
	value= changevalue(value)
	print ('The value is ', value)
	#value = changevalue(value)
def changevalue(value):
	value = 50
	value=value+10
	return value
#calls main
main()