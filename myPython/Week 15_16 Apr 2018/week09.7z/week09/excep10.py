def convertme(v):
	try:
		x= int(v)
		y =x +20
		return y
	#except ValueError:
	except ValueError as argmnt:
		print ("The argument does not have numbers\n", argmnt)
		#print ("The argument does not have numbers\n")

# Call above function here.
print (convertme('f'))
