try:
	val = float(input("Enter a number: "))
	result = 5.0 / val
except  Exception:
	print (" An Error!")
else:
	dict = {'a1':'3', 'k1':'89', 'z4':'5','':'0'};
	sortedDict = sorted(dict.items())
	search= 'g'
	for k,v in sortedDict:
		print (k, v)
		if search ==k:
			print("ok")
		else:
			print("not ok")
print ("\n","Thanks!")