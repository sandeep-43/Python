try:
	fh = open("file1.txt", "r")
	fh.write("This is my test file for exception handling!!")
except IOError:
	print ("Error: can\'t find file or read data")
else:
	x=1
	g=3
	z=x+g
	print (z)
	# to add fun03 code here for testing
	