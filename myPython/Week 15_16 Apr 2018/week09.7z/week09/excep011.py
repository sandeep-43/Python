fh = open("file1.txt", "r")
fh.write("This is my test file for exception handling!!")